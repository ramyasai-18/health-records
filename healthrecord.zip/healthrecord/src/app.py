from flask import Flask, request, render_template, jsonify
from web3 import Web3, HTTPProvider
import json
import urllib3

blockchain = 'http://127.0.0.1:7545'

# Function to connect to the blockchain and contract
def connect():
    web3 = Web3(HTTPProvider(blockchain))
    web3.eth.defaultAccount = web3.eth.accounts[0]

    artifact = "../build/contracts/HealthRecord.json"
    with open(artifact) as f:
        artifact_json = json.load(f)
        contract_abi = artifact_json['abi']
        contract_address = artifact_json['networks']['5777']['address']

    contract = web3.eth.contract(
        abi=contract_abi,
        address=contract_address
    )
    return contract, web3

app = Flask(__name__)  # Corrected from _name_ to __name__

@app.route('/', methods=['GET'])
def home():
    return render_template('home.html')

@app.route('/addHealthRecord', methods=['GET', 'POST'])
def add_health_record():
    try:
        name = request.args.get('name')
        age = int(request.args.get('age'))
        diseases = request.args.get('diseases')

        if not name or not diseases:
            return "Name and diseases are required.", 400

        contract, web3 = connect()
        tx_hash = contract.functions.setHealthRecord(name, age, diseases).transact()
        web3.eth.waitForTransactionReceipt(tx_hash)
        return 'Health Record Added Successfully'
    except Exception as e:
        return f'Transaction Error: {str(e)}', 500

@app.route('/verifyHealthRecord', methods=['GET'])
def verify_health_record():
    patient_address = request.args.get('address')
    
    contract, web3 = connect()
    try:
        record = contract.functions.getHealthRecord(patient_address).call()
        return jsonify({
            'name': record[0],
            'age': record[1],
            'diseases': record[2]
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/addhealthrecordform', methods=['POST'])
def add_health_record_form():
    name = request.form['name']
    age = request.form['age']
    diseases = request.form['diseases']
    
    pipe = urllib3.PoolManager()
    response = pipe.request('GET', f'http://127.0.0.1:4000/addHealthRecord?name={name}&age={age}&diseases={diseases}')
    response_message = response.data.decode('utf-8')
    
    # Show the "Add Health Record" form after submission
    return render_template('home.html', add_response=response_message, show_add_form=True)

@app.route('/verifyhealthrecordform', methods=['POST'])
def verify_health_record_form():
    patient_address = request.form['address']
    
    pipe = urllib3.PoolManager()
    response = pipe.request('GET', f'http://127.0.0.1:4000/verifyHealthRecord?address={patient_address}')
    response_data = response.data.decode('utf-8')
    
    try:
        record = json.loads(response_data)
        return render_template('home.html', patient_record=record, show_verify_form=True)
    except json.JSONDecodeError:
        return render_template('home.html', verify_response='Record not found or invalid address.', show_verify_form=True)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=4000)
